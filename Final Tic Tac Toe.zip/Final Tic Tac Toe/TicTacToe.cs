﻿using System;
using System.Collections.Generic;

namespace TicTacToe

{
    [Serializable]
    public class TicTacToe
    {
        bool closeRequested = false;
        public bool saveRequested = false;
        bool playerTurn = true;
        char[,] board;


        public TicTacToe()
        {
            // Initializes board array with empty characters.
            initialize();
        }

        public void initialize()
        {
            board = new char[3, 3]
                  {
                    { ' ', ' ', ' ', },
                    { ' ', ' ', ' ', },
                    { ' ', ' ', ' ', },
                  };
        }

        public bool Run()
        {
            // Render board characters on tictactoe board.
            DrawBoard();

            while (!closeRequested && !saveRequested)
            {
                while (!closeRequested && !saveRequested)
                {
                    if (playerTurn)
                    {
                        PlayerTurn();
                        if (CheckForThree('X'))
                        {
                            FinishGame("You Win.");
                            break;
                        }
                    }
                    else
                    {
                        AutomatedTurn();
                        if (CheckForThree('O'))
                        {
                            FinishGame("You Lose.");
                            break;
                        }
                    }
                    playerTurn = !playerTurn;
                    if (CheckForFullBoard())
                    {
                        FinishGame("Draw.");
                        break;
                    }
                }

                if (saveRequested)
                {
                    return true;
                }

                if (!closeRequested && !saveRequested)
                {
                    bool loopForAnswer = true;
                    while (loopForAnswer)
                    {
                        Console.WriteLine();
                        Console.WriteLine("\nWould you like to play again?\n\nTo play press[enter], to quit press[end]");

                        switch (Console.ReadKey(true).Key)
                        {
                            case ConsoleKey.Enter:
                                initialize();
                                loopForAnswer = false;
                                break;
                            case ConsoleKey.End:
                                closeRequested = true;
                                Console.Clear();
                                loopForAnswer = false;
                                break;
                            default:
                                loopForAnswer = true;
                                break;

                        }
                    }
                }
            }

            return false;
        }
        void PlayerTurn()
        {
            int row = 0, column = 0;
            bool moved = false;
            while (!moved && !closeRequested && !saveRequested)
            {
                Console.Clear();
                DrawBoard();
                Console.WriteLine();
                if(board[row, column] is 'X' || board[row, column] is 'O')
                {
                    Console.WriteLine("This position is already used.... Use another position\n\n");
                }
                Console.WriteLine("Choose a valid position and press enter. \n");
                Console.WriteLine("**To quit press [end] key \n**To save press [escape] key ");
                Console.SetCursorPosition(column * 6 + 1, row * 4 + 1);
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.UpArrow: row = row <= 0 ? 2 : row - 1; break;
                    case ConsoleKey.DownArrow: row = row >= 2 ? 0 : row + 1; break;
                    case ConsoleKey.LeftArrow: column = column <= 0 ? 2 : column - 1; break;
                    case ConsoleKey.RightArrow: column = column >= 2 ? 0 : column + 1; break;
                    case ConsoleKey.Enter:
                         if (board[row, column] is ' ')
                            {
                                board[row, column] = 'X';
                                moved = true;
                            }
                            break;
                    case ConsoleKey.End:
                        Console.Clear();
                        closeRequested = true;
                        break;
                    case ConsoleKey.Escape:
                        Console.Clear();
                        saveRequested = true;
                        break;
                }
            }
        }

        void AutomatedTurn()
        {
            Random random = new Random();
            var possibleMoves = new List<(int X, int Y)>();
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (board[i, j] == ' ')
                    {
                        possibleMoves.Add((i, j));
                    }
                }
            }
            int index = random.Next(0, possibleMoves.Count);
            var (X, Y) = possibleMoves[index];
            board[X, Y] = 'O';
        }

        bool CheckForThree(char c)
        {
            return board[0, 0] == c && board[1, 0] == c && board[2, 0] == c ||
             board[0, 1] == c && board[1, 1] == c && board[2, 1] == c ||
             board[0, 2] == c && board[1, 2] == c && board[2, 2] == c ||
             board[0, 0] == c && board[0, 1] == c && board[0, 2] == c ||
             board[1, 0] == c && board[1, 1] == c && board[1, 2] == c ||
             board[2, 0] == c && board[2, 1] == c && board[2, 2] == c ||
             board[0, 0] == c && board[1, 1] == c && board[2, 2] == c ||
             board[2, 0] == c && board[1, 1] == c && board[0, 2] == c;

        }

        bool CheckForFullBoard()
        {
            bool isFull = board[0, 0] != ' ' && board[1, 0] != ' ' && board[2, 0] != ' ' &&
            board[0, 1] != ' ' && board[1, 1] != ' ' && board[2, 1] != ' ' &&
            board[0, 2] != ' ' && board[1, 2] != ' ' && board[2, 2] != ' ';

            return isFull;
        }

        void DrawBoard()
        {
            Console.WriteLine();
            Console.WriteLine($" {board[0, 0]}  ||  {board[0, 1]}  ||  {board[0, 2]}");
            Console.WriteLine("    ||     ||");
            Console.WriteLine(" ===||=====||===");
            Console.WriteLine("    ||     ||");
            Console.WriteLine($" {board[1, 0]}  ||  {board[1, 1]}  ||  {board[1, 2]}");
            Console.WriteLine("    ||     ||");
            Console.WriteLine(" ===||=====||===");
            Console.WriteLine("    ||     ||");
            Console.WriteLine($" {board[2, 0]}  ||  {board[2, 1]}  ||  {board[2, 2]}");
        }

        void FinishGame(string message)
        {
            Console.Clear();
            DrawBoard();
            Console.WriteLine();
            Console.Write(message);
        }
    }
}

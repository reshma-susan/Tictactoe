﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

namespace TicTacToe
{
    public class Program
    {
        public const string IntroMessage = "Hello, welcome to the game. Please enter your profile name.";

        public const string Delimiter = "--------------------------------------------------------------------------------";

        public static void Main(string[] args)
        {
            //Start Intro information

            Console.WriteLine(IntroMessage);
            Console.WriteLine(Delimiter);
            Console.WriteLine();
            
            //End Intro information

            // Reads user profile name, till only aphabtes are given
            string profileName = "";
            bool validName = false;
            bool validOption = false;
            do
            {
                profileName = Console.ReadLine();
                profileName = profileName.ToLower();
                if (profileName.Length > 0)
                {
                    Regex r = new Regex("^[a-zA-Z]+$");

                    if (r.IsMatch(profileName))
                        validName = true;
                    else
                        validName = false;
                }

                if (!validName)
                {
                    Console.WriteLine("Only alphabets are allowed as profile name....Try another name\n");
                }

            } while (!validName);

            // End Reads user profile name, till only aphabtes are given


            // Check if user has any saved games.
            TicTacToe app = null;
            var savedGamePath = Directory.GetCurrentDirectory() + "\\Profiles\\" + profileName + "-savedgame.txt";
            if (File.Exists(savedGamePath))
            {
                Console.WriteLine("");
                Console.WriteLine(profileName+ ", you have already saved games... Do you wish to continue. \n\n");
                Console.WriteLine("Enter Yes to continue or enter No to start a new game.\n");
                do
                {
                    string userOption = Console.ReadLine();
                    if (userOption.ToLower().Equals("yes"))
                    {
                        using (FileStream fs = new FileStream(savedGamePath, FileMode.Open, FileAccess.Read))
                        {
                            BinaryFormatter bf = new BinaryFormatter();
                            app = (TicTacToe)bf.Deserialize(fs);
                            app.saveRequested = false;
                            validOption = true;
                        }
                    }
                    else if (userOption.ToLower().Equals("no"))
                    {
                        File.Delete(savedGamePath);
                        validOption = true;
                    }
                    else
                    {
                        Console.WriteLine("Please type Yes to continue or type No to start a new game");
                            validOption = false;
                    }
                } while (!validOption);
            }

            // If no saved state exits or new game.
            if (app == null)
            {
                app = new TicTacToe();
            }

            // Clear console.
            Console.Clear();

            var shouldSaveState = app.Run();
            if (shouldSaveState)
            {
                using (FileStream fs = new FileStream(savedGamePath, FileMode.Create, FileAccess.Write))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(fs, app);
                }
                Console.WriteLine("State saved.");
            }


            Console.WriteLine("\nPress <Enter> to continue...");
            Console.ReadLine();
        }

    }

}